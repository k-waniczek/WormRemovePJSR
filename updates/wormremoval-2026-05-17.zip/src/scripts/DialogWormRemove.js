class WormRemoveDialog extends Dialog {

    constructor() {
        super();
        
        this.width = 450;
        this.minWidth = 450;
        this.height = 450;
        this.minHeight = 450;

        this.title = new TextBox(this);
        this.title.text = "<b>Worm Removal Script</b> <br><br>" +
            "Script uses BlurXterminator and StarXterminator in the correct orders as to minimize the occurance of \"worms\" in images after star removal";

        this.title.readOnly = true;
        this.title.minHeight = 90;
        this.title.maxHeight = 90;

        this.sharpenStars = new NumericControl(this);
        this.sharpenStars.label.text = "Sharpen stars:";
        this.sharpenStars.setPrecision(2);
        this.sharpenStars.slider.setRange(0, 700);
        this.sharpenStars.setRange(0.0, 0.7);
        this.sharpenStars.setValue(xtParameters.sharpenStars);
        this.sharpenStars.toolTip = "<p>Sharpen stars parameter from BlurXterminator</p>";
        this.sharpenStars.onValueUpdated = function (value) { xtParameters.sharpenStars = value };

        this.sharpenNonStellar = new NumericControl(this);
        this.sharpenNonStellar.label.text = "Sharpen nonstellar:";
        this.sharpenNonStellar.setPrecision(2);
        this.sharpenNonStellar.slider.setRange(0, 100);
        this.sharpenNonStellar.setRange(0.0, 1.0);
        this.sharpenNonStellar.setValue(xtParameters.sharpenNonstellar);
        this.sharpenNonStellar.toolTip = "<p>Sharpen nonstellar parameter from BlurXterminator</p>";
        this.sharpenNonStellar.onValueUpdated = function (value) { xtParameters.sharpenNonstellar = value };

        this.adjustHalos = new NumericControl(this);
        this.adjustHalos.label.text = "Adjust halos:";
        this.adjustHalos.setPrecision(2);
        this.adjustHalos.slider.setRange(0, 100);
        this.adjustHalos.setRange(-0.5, 0.5);
        this.adjustHalos.setValue(xtParameters.adjustHalos);
        this.adjustHalos.toolTip = "<p>Adjust halos parameter from BlurXterminator</p>";
        this.adjustHalos.onValueUpdated = function (value) { xtParameters.adjustHalos = value };

        this.largeOverlap = new CheckBox(this);
        this.largeOverlap.text = "Large overlap";
        this.largeOverlap.checked = xtParameters.overlap ? true : false;
        this.largeOverlap.toolTip = "<p>Large overlap option in StarXterminator";
        this.largeOverlap.onCheck = function (value) { xtParameters.overlap = value ? 0.5 : 0.2 };

        this.correctFirst = new CheckBox(this);
        this.correctFirst.text = "Correct first";
        this.correctFirst.checked = xtParameters.correct;
        this.correctFirst.toolTip = "<p>Correct first option in BlurXterminator";
        this.correctFirst.onCheck = function (value) { xtParameters.correct = value };

        this.generateStarMask = new CheckBox(this);
        this.generateStarMask.text = "Generate star mask";
        this.generateStarMask.checked = xtParameters.generateStarMask;
        this.generateStarMask.toolTip = "<p>Generate star mask option in StarXterminator";
        this.generateStarMask.onCheck = function (value) { xtParameters.generateStarMask = value };

        this.viewToEdit = new ViewList(this);
        this.viewToEdit.getMainViews();
        this.viewToEdit.onViewSelected = function(view) {
            xtParameters.view = view.id;
        }
        if (xtParameters.view) {
            this.viewToEdit.currentView = View.viewById(xtParameters.view);
        }

        //Execute Button
        this.execButton = new PushButton(this);
        this.execButton.text = "Execute";
        this.execButton.width = 40;
        this.execButton.enabled = true;
        this.execButton.onClick = () => {
            this.ok();
        }

        this.newInstanceButton = new ToolButton(this);
        this.newInstanceButton.icon = this.scaledResource( ":/process-interface/new-instance.png" );
        this.newInstanceButton.setScaledFixedSize(24, 24);
        this.newInstanceButton.toolTip = "New Instance.";
        this.newInstanceButton.onMousePress = () => {
            saveParameters();
            this.newInstance();
        }

        this.buttonSizer = new HorizontalSizer;
        this.buttonSizer.margin = 4;
        this.buttonSizer.spacing = 4;
        this.buttonSizer.addSpacing(8);
        this.buttonSizer.spacing = 4;
        this.buttonSizer.add(this.newInstanceButton);
        this.buttonSizer.addStretch();

        this.viewGroupSizer = new VerticalSizer;
        this.viewGroupSizer.margin = 10;
        this.viewGroupSizer.add(this.viewToEdit);
        this.viewGroup = new GroupBox(this);
        this.viewGroup.title = "View";
        this.viewGroup.sizer = this.viewGroupSizer;

        //BlulXterminator and StarXterminator parameters page
        this.xtvsizer = new VerticalSizer;
        this.xtvsizer.margin = 10;
        this.xtvsizer.add(this.sharpenStars);
        this.xtvsizer.addSpacing(5);
        this.xtvsizer.add(this.adjustHalos);
        this.xtvsizer.addSpacing(5);
        this.xtvsizer.add(this.sharpenNonStellar);
        this.xtvsizer.addSpacing(10);
        this.xtvsizer.add(this.largeOverlap);
        this.xtvsizer.addSpacing(10);
        this.xtvsizer.add(this.generateStarMask);
        this.xtvsizer.addSpacing(10);
        this.xtvsizer.add(this.correctFirst);
        this.xtvsizer.addSpacing(5);
        this.xtGroup = new GroupBox(this);
        this.xtGroup.title = "BlurXterminator and StarXterminator parameters";
        this.xtGroup.sizer = this.xtvsizer;

        //Bottom Buttons
        this.bottomSizer = new HorizontalSizer;
        this.bottomSizer.margin = 8;
        this.bottomSizer.add(this.execButton);


        this.sizer = new VerticalSizer;
        this.sizer.margin = 8;
        this.sizer.add(this.title);
        this.sizer.addSpacing(8);
        this.sizer.add(this.viewGroup);
        this.sizer.addSpacing(8);
        this.sizer.add(this.xtGroup);
        this.sizer.addSpacing(8);
        this.sizer.add(this.bottomSizer);
        this.sizer.addSpacing(2);
        this.sizer.add(this.buttonSizer);
        this.sizer.addStretch();
    }
}